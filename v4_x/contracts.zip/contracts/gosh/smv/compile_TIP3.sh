#!/bin/bash

everdev sol compile ./External/tip3/TokenRoot.sol
everdev sol compile ./External/tip3/TokenWallet.sol
